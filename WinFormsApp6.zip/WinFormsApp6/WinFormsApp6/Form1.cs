using System;

namespace WinFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private List<Vehicle> _vehicle = new List<Vehicle>();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            Vehicle vehicle1 = new Vehicle
            {
                //Brands = cmbBrands.Text,
                //Models = cmbModels.Text,
                Km = txtKm.Text,
                Year = txtYear.Text,
            };
            _vehicle.Add(vehicle1);

            lstBrandModel.Items.Add(vehicle1);

            //lstBrandModel.DataSource = null;
            //lstBrandModel.DisplayMember = nameof(Vehicle.Km);
            //lstBrandModel.ValueMember = nameof(Vehicle.Year);
            //lstBrandModel.DataSource = _vehicle;
        }

        private void btnAddBrand_Click(object sender, EventArgs e)
        {
            Brand brand = new Brand
            {
                BrandName = txtBrandName.Text,
            };
            lstBrand.Items.Add(brand);
        }
        private void lstBrand_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = lstBrand.SelectedIndex;
        }
        private void btnDeleteBrand_Click(object sender, EventArgs e)
        {
            int index = lstBrand.SelectedIndex;
            lstBrand.Items.RemoveAt(index);
        }

        private void btnEditBrand_Click(object sender, EventArgs e)
        {
            int index = lstBrand.SelectedIndex;
            txtBrandName.Text = (string)lstBrand.Items[index];

        }
    }
}