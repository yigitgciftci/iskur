﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WinFormsApp6
{
    internal class Vehicle
    {
        public override string ToString()
        {
            return $"{Brands}|{Models}|{Km}|{Year}|{DailyRentalPrice}";
        }
        public Brand Brands { get; set; }
        public Model Models { get; set; }
        public string Km { get; set; }
        public string Year { get; set; }
        public int DailyRentalPrice  { get; set; }
    }
    public class Brand
    {
        public override string ToString()
        {
            return $"{BrandName}";
        }
        public string BrandName { get; set; }
    }
    public class Model
    {
        public string ModelName { get; set; }
    }
    public class Person
    {
        public string FullName { get; set; }
        public string IdentifyNumber { get; set; }
    }
    public class Rent
    {
        public DateTime StartDate { get; set; }
        public DateTime FinishDate { get; set; }
        public string DownPayment { get; set; }
    }
}
