﻿namespace WinFormsApp6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.label1 = new System.Windows.Forms.Label();
            this.lstBrandModel = new System.Windows.Forms.ListBox();
            this.btnDeleteBrandModel = new System.Windows.Forms.Button();
            this.cmbBrands = new System.Windows.Forms.ComboBox();
            this.cmbModels = new System.Windows.Forms.ComboBox();
            this.txtKm = new System.Windows.Forms.TextBox();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.chkRent = new System.Windows.Forms.CheckBox();
            this.nudRentalPrice = new System.Windows.Forms.NumericUpDown();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnRent = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.txtIdentifyNumber = new System.Windows.Forms.TextBox();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.dtpFinishDate = new System.Windows.Forms.DateTimePicker();
            this.nudDownPayment = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lstRentalList = new System.Windows.Forms.ListBox();
            this.btnDeleteRentList = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnChoosePicture = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabFile = new System.Windows.Forms.TabControl();
            this.tcFile = new System.Windows.Forms.TabPage();
            this.tcBrandManage = new System.Windows.Forms.TabPage();
            this.lstBrand = new System.Windows.Forms.ListBox();
            this.btnEditBrand = new System.Windows.Forms.Button();
            this.btnDeleteBrand = new System.Windows.Forms.Button();
            this.btnAddBrand = new System.Windows.Forms.Button();
            this.txtBrandName = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tcModelManage = new System.Windows.Forms.TabPage();
            ((System.ComponentModel.ISupportInitialize)(this.nudRentalPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDownPayment)).BeginInit();
            this.tabFile.SuspendLayout();
            this.tcFile.SuspendLayout();
            this.tcBrandManage.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1032, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(273, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Vehicle Info";
            // 
            // lstBrandModel
            // 
            this.lstBrandModel.FormattingEnabled = true;
            this.lstBrandModel.ItemHeight = 15;
            this.lstBrandModel.Location = new System.Drawing.Point(23, 43);
            this.lstBrandModel.Name = "lstBrandModel";
            this.lstBrandModel.Size = new System.Drawing.Size(214, 379);
            this.lstBrandModel.TabIndex = 2;
            // 
            // btnDeleteBrandModel
            // 
            this.btnDeleteBrandModel.Location = new System.Drawing.Point(162, 436);
            this.btnDeleteBrandModel.Name = "btnDeleteBrandModel";
            this.btnDeleteBrandModel.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteBrandModel.TabIndex = 3;
            this.btnDeleteBrandModel.Text = "Delete";
            this.btnDeleteBrandModel.UseVisualStyleBackColor = true;
            // 
            // cmbBrands
            // 
            this.cmbBrands.FormattingEnabled = true;
            this.cmbBrands.Location = new System.Drawing.Point(352, 43);
            this.cmbBrands.Name = "cmbBrands";
            this.cmbBrands.Size = new System.Drawing.Size(121, 23);
            this.cmbBrands.TabIndex = 4;
            // 
            // cmbModels
            // 
            this.cmbModels.FormattingEnabled = true;
            this.cmbModels.Location = new System.Drawing.Point(352, 87);
            this.cmbModels.Name = "cmbModels";
            this.cmbModels.Size = new System.Drawing.Size(121, 23);
            this.cmbModels.TabIndex = 4;
            // 
            // txtKm
            // 
            this.txtKm.Location = new System.Drawing.Point(352, 129);
            this.txtKm.Name = "txtKm";
            this.txtKm.Size = new System.Drawing.Size(121, 23);
            this.txtKm.TabIndex = 5;
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(352, 169);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(121, 23);
            this.txtYear.TabIndex = 5;
            // 
            // chkRent
            // 
            this.chkRent.AutoSize = true;
            this.chkRent.Location = new System.Drawing.Point(352, 213);
            this.chkRent.Name = "chkRent";
            this.chkRent.Size = new System.Drawing.Size(118, 19);
            this.chkRent.TabIndex = 6;
            this.chkRent.Text = "Can it be rented ?";
            this.chkRent.UseVisualStyleBackColor = true;
            // 
            // nudRentalPrice
            // 
            this.nudRentalPrice.Location = new System.Drawing.Point(377, 245);
            this.nudRentalPrice.Name = "nudRentalPrice";
            this.nudRentalPrice.Size = new System.Drawing.Size(96, 23);
            this.nudRentalPrice.TabIndex = 7;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::WinFormsApp6.Properties.Resources.image_128;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Location = new System.Drawing.Point(352, 285);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(121, 126);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // btnRent
            // 
            this.btnRent.Location = new System.Drawing.Point(691, 247);
            this.btnRent.Name = "btnRent";
            this.btnRent.Size = new System.Drawing.Size(75, 23);
            this.btnRent.TabIndex = 9;
            this.btnRent.Text = "Rent";
            this.btnRent.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(498, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Renter Info";
            // 
            // txtFullName
            // 
            this.txtFullName.Location = new System.Drawing.Point(601, 43);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(165, 23);
            this.txtFullName.TabIndex = 5;
            // 
            // txtIdentifyNumber
            // 
            this.txtIdentifyNumber.Location = new System.Drawing.Point(601, 87);
            this.txtIdentifyNumber.Name = "txtIdentifyNumber";
            this.txtIdentifyNumber.Size = new System.Drawing.Size(165, 23);
            this.txtIdentifyNumber.TabIndex = 5;
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStartDate.Location = new System.Drawing.Point(601, 129);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(165, 23);
            this.dtpStartDate.TabIndex = 10;
            // 
            // dtpFinishDate
            // 
            this.dtpFinishDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFinishDate.Location = new System.Drawing.Point(601, 169);
            this.dtpFinishDate.Name = "dtpFinishDate";
            this.dtpFinishDate.Size = new System.Drawing.Size(165, 23);
            this.dtpFinishDate.TabIndex = 10;
            // 
            // nudDownPayment
            // 
            this.nudDownPayment.Location = new System.Drawing.Point(601, 209);
            this.nudDownPayment.Name = "nudDownPayment";
            this.nudDownPayment.Size = new System.Drawing.Size(165, 23);
            this.nudDownPayment.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(786, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Rental List";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 15);
            this.label4.TabIndex = 1;
            this.label4.Text = "Vehicles";
            // 
            // lstRentalList
            // 
            this.lstRentalList.FormattingEnabled = true;
            this.lstRentalList.ItemHeight = 15;
            this.lstRentalList.Location = new System.Drawing.Point(786, 43);
            this.lstRentalList.Name = "lstRentalList";
            this.lstRentalList.Size = new System.Drawing.Size(214, 379);
            this.lstRentalList.TabIndex = 2;
            // 
            // btnDeleteRentList
            // 
            this.btnDeleteRentList.Location = new System.Drawing.Point(925, 436);
            this.btnDeleteRentList.Name = "btnDeleteRentList";
            this.btnDeleteRentList.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteRentList.TabIndex = 9;
            this.btnDeleteRentList.Text = "Delete";
            this.btnDeleteRentList.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(422, 436);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 9;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnChoosePicture
            // 
            this.btnChoosePicture.Location = new System.Drawing.Point(352, 407);
            this.btnChoosePicture.Name = "btnChoosePicture";
            this.btnChoosePicture.Size = new System.Drawing.Size(121, 23);
            this.btnChoosePicture.TabIndex = 9;
            this.btnChoosePicture.Text = "Choose Picture";
            this.btnChoosePicture.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(498, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "Person Full Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(498, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 15);
            this.label6.TabIndex = 1;
            this.label6.Text = "Identify Number";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(498, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 15);
            this.label7.TabIndex = 1;
            this.label7.Text = "Start Date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(498, 172);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 15);
            this.label8.TabIndex = 1;
            this.label8.Text = "Finish Date";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(498, 211);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 15);
            this.label9.TabIndex = 1;
            this.label9.Text = "Down Payment";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(274, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 15);
            this.label10.TabIndex = 1;
            this.label10.Text = "Models";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(274, 129);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 15);
            this.label11.TabIndex = 1;
            this.label11.Text = "KM";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(274, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 15);
            this.label12.TabIndex = 1;
            this.label12.Text = "Brands";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(274, 169);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 15);
            this.label13.TabIndex = 1;
            this.label13.Text = "Year";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(273, 247);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 15);
            this.label14.TabIndex = 1;
            this.label14.Text = "Daily Rental Price";
            // 
            // tabFile
            // 
            this.tabFile.Controls.Add(this.tcFile);
            this.tabFile.Controls.Add(this.tcBrandManage);
            this.tabFile.Controls.Add(this.tcModelManage);
            this.tabFile.Location = new System.Drawing.Point(12, 12);
            this.tabFile.Name = "tabFile";
            this.tabFile.SelectedIndex = 0;
            this.tabFile.Size = new System.Drawing.Size(1024, 501);
            this.tabFile.TabIndex = 0;
            // 
            // tcFile
            // 
            this.tcFile.Controls.Add(this.label4);
            this.tcFile.Controls.Add(this.btnDeleteRentList);
            this.tcFile.Controls.Add(this.dtpFinishDate);
            this.tcFile.Controls.Add(this.lstRentalList);
            this.tcFile.Controls.Add(this.label1);
            this.tcFile.Controls.Add(this.label3);
            this.tcFile.Controls.Add(this.dtpStartDate);
            this.tcFile.Controls.Add(this.label10);
            this.tcFile.Controls.Add(this.btnChoosePicture);
            this.tcFile.Controls.Add(this.btnRent);
            this.tcFile.Controls.Add(this.label12);
            this.tcFile.Controls.Add(this.nudDownPayment);
            this.tcFile.Controls.Add(this.btnAdd);
            this.tcFile.Controls.Add(this.txtIdentifyNumber);
            this.tcFile.Controls.Add(this.label11);
            this.tcFile.Controls.Add(this.txtFullName);
            this.tcFile.Controls.Add(this.label13);
            this.tcFile.Controls.Add(this.label14);
            this.tcFile.Controls.Add(this.pictureBox1);
            this.tcFile.Controls.Add(this.label9);
            this.tcFile.Controls.Add(this.lstBrandModel);
            this.tcFile.Controls.Add(this.label8);
            this.tcFile.Controls.Add(this.btnDeleteBrandModel);
            this.tcFile.Controls.Add(this.label7);
            this.tcFile.Controls.Add(this.nudRentalPrice);
            this.tcFile.Controls.Add(this.label6);
            this.tcFile.Controls.Add(this.cmbBrands);
            this.tcFile.Controls.Add(this.label5);
            this.tcFile.Controls.Add(this.chkRent);
            this.tcFile.Controls.Add(this.label2);
            this.tcFile.Controls.Add(this.cmbModels);
            this.tcFile.Controls.Add(this.txtYear);
            this.tcFile.Controls.Add(this.txtKm);
            this.tcFile.Location = new System.Drawing.Point(4, 24);
            this.tcFile.Name = "tcFile";
            this.tcFile.Padding = new System.Windows.Forms.Padding(3);
            this.tcFile.Size = new System.Drawing.Size(1016, 473);
            this.tcFile.TabIndex = 0;
            this.tcFile.Text = "File";
            this.tcFile.UseVisualStyleBackColor = true;
            // 
            // tcBrandManage
            // 
            this.tcBrandManage.Controls.Add(this.lstBrand);
            this.tcBrandManage.Controls.Add(this.btnEditBrand);
            this.tcBrandManage.Controls.Add(this.btnDeleteBrand);
            this.tcBrandManage.Controls.Add(this.btnAddBrand);
            this.tcBrandManage.Controls.Add(this.txtBrandName);
            this.tcBrandManage.Controls.Add(this.label15);
            this.tcBrandManage.Location = new System.Drawing.Point(4, 24);
            this.tcBrandManage.Name = "tcBrandManage";
            this.tcBrandManage.Padding = new System.Windows.Forms.Padding(3);
            this.tcBrandManage.Size = new System.Drawing.Size(1016, 473);
            this.tcBrandManage.TabIndex = 1;
            this.tcBrandManage.Text = "Brand Manage";
            this.tcBrandManage.UseVisualStyleBackColor = true;
            // 
            // lstBrand
            // 
            this.lstBrand.FormattingEnabled = true;
            this.lstBrand.ItemHeight = 15;
            this.lstBrand.Location = new System.Drawing.Point(175, 42);
            this.lstBrand.Name = "lstBrand";
            this.lstBrand.Size = new System.Drawing.Size(324, 379);
            this.lstBrand.TabIndex = 3;
            this.lstBrand.SelectedIndexChanged += new System.EventHandler(this.lstBrand_SelectedIndexChanged);
            // 
            // btnEditBrand
            // 
            this.btnEditBrand.Location = new System.Drawing.Point(597, 223);
            this.btnEditBrand.Name = "btnEditBrand";
            this.btnEditBrand.Size = new System.Drawing.Size(75, 23);
            this.btnEditBrand.TabIndex = 2;
            this.btnEditBrand.Text = "Edit";
            this.btnEditBrand.UseVisualStyleBackColor = true;
            this.btnEditBrand.Click += new System.EventHandler(this.btnEditBrand_Click);
            // 
            // btnDeleteBrand
            // 
            this.btnDeleteBrand.Location = new System.Drawing.Point(660, 185);
            this.btnDeleteBrand.Name = "btnDeleteBrand";
            this.btnDeleteBrand.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteBrand.TabIndex = 2;
            this.btnDeleteBrand.Text = "Delete";
            this.btnDeleteBrand.UseVisualStyleBackColor = true;
            this.btnDeleteBrand.Click += new System.EventHandler(this.btnDeleteBrand_Click);
            // 
            // btnAddBrand
            // 
            this.btnAddBrand.Location = new System.Drawing.Point(540, 185);
            this.btnAddBrand.Name = "btnAddBrand";
            this.btnAddBrand.Size = new System.Drawing.Size(75, 23);
            this.btnAddBrand.TabIndex = 2;
            this.btnAddBrand.Text = "Add";
            this.btnAddBrand.UseVisualStyleBackColor = true;
            this.btnAddBrand.Click += new System.EventHandler(this.btnAddBrand_Click);
            // 
            // txtBrandName
            // 
            this.txtBrandName.Location = new System.Drawing.Point(635, 133);
            this.txtBrandName.Name = "txtBrandName";
            this.txtBrandName.Size = new System.Drawing.Size(100, 23);
            this.txtBrandName.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(540, 136);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 15);
            this.label15.TabIndex = 0;
            this.label15.Text = "Brand Name";
            // 
            // tcModelManage
            // 
            this.tcModelManage.Location = new System.Drawing.Point(4, 24);
            this.tcModelManage.Name = "tcModelManage";
            this.tcModelManage.Padding = new System.Windows.Forms.Padding(3);
            this.tcModelManage.Size = new System.Drawing.Size(1016, 473);
            this.tcModelManage.TabIndex = 2;
            this.tcModelManage.Text = "Model Manage";
            this.tcModelManage.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1032, 509);
            this.Controls.Add(this.tabFile);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudRentalPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDownPayment)).EndInit();
            this.tabFile.ResumeLayout(false);
            this.tcFile.ResumeLayout(false);
            this.tcFile.PerformLayout();
            this.tcBrandManage.ResumeLayout(false);
            this.tcBrandManage.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip1;
        private Label label1;
        private ListBox lstBrandModel;
        private Button btnDeleteBrandModel;
        private ComboBox cmbBrands;
        private ComboBox cmbModels;
        private TextBox txtKm;
        private TextBox txtYear;
        private CheckBox chkRent;
        private NumericUpDown nudRentalPrice;
        private PictureBox pictureBox1;
        private Button btnRent;
        private Label label2;
        private TextBox txtFullName;
        private TextBox txtIdentifyNumber;
        private DateTimePicker dtpStartDate;
        private DateTimePicker dtpFinishDate;
        private NumericUpDown nudDownPayment;
        private Label label3;
        private Label label4;
        private ListBox lstRentalList;
        private Button btnDeleteRentList;
        private Button btnAdd;
        private Button btnChoosePicture;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private TabControl tabFile;
        private TabPage tcFile;
        private TabPage tcBrandManage;
        private TabPage tcModelManage;
        private Button btnEditBrand;
        private Button btnDeleteBrand;
        private Button btnAddBrand;
        private TextBox txtBrandName;
        private Label label15;
        private ListBox lstBrand;
    }
}